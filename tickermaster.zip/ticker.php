<?php
/*
Plugin Name: News Ticker Master
Plugin URI: http://wordpress.org/plugins/news-ticker-master/
Description: A powerful, flexible and animated vertical news ticker plugin.
Author: Biman Dash
Version: 1.0
Author URI: https://ticker-master.000webhostapp.com/ticker-master-demo/
*/
function ticker_wp_latest_jqurey(){
	wp_enqueue_script('jQuery');
}
add_action('init','ticker_wp_latest_jqurey');


function register_file() {
wp_enqueue_script( 'ticker_master_js', plugins_url('/js/jquery.ticker.min.js', __FILE__), array('jquery'), '1.0.',false );
wp_enqueue_style( 'ticker_master_css', plugins_url('/css/style.css', __FILE__));

}
    add_action('init', 'register_file');
	




function ticker_master_markup_test($atts){
  extract(shortcode_atts(array( 
  'id' => 'ticker_master',
   'catagory' => '',
   'count' => '5',
   'category_slug ' => 'category_id',
   'speed' => '3000',
   'typespeed' => '50',
   'fadeitem' => 'true',
   'fadeitem_in' => '600',
   'fadeitem_out' => '300',
   'color' => '#000',
   'text' => 'News',
   
   ), $atts,'projects'));

  $q=new wp_Query(
  array('posts_per_page' => $count,'post_type' => 'post','category_slug' => '$catagory')
);
  $post = '<script type="text/javascript">
jQuery(document).ready(function(){
   jQuery("#ticker'.$id.'").ticker({
         itemspreed:'.$speed.',
         cursorSpeed:'.$typespeed.',
         fade:'.$fadeitem.',
         fadeInSpeed:'.$fadeitem_in.',
         fadeOutSpeed:'.$fadeitem_out.',
   });
});

</script>
<div id="ticker'.$id.'" class="ticker"><strong style="background-color:'.$color.'">'.$text.'</strong><ul>';
  
  while ($q->have_posts()):$q->the_post();
     $post.= '<li><a href="'.get_permalink().'"title="' . get_the_title() . '">'.get_the_title().' </a></li>';   
   
    endwhile;
  $post.='</ul></div>';
  wp_reset_query();
  return $post;
}

add_shortcode('tickr','ticker_master_markup_test');





?>